package Display;

import static Models.Join.JoinL;

public class Display {
	public static void DisplayMainMenu()
	{
		System.out.println("Welcome to Hackathon Team Management!");
		System.out.println("1. Menu Utama");
		System.out.println("2. Insert Data");
		System.out.println("3. Show");
		System.out.println("4. ShowOne");
		System.out.println("5. Exit");
		System.out.println("Choose[1-5]: ");
	}
	
	public static void DisplayExit()
	{
		System.out.println("Exiting Program...");
		System.out.println("Goodbye! :D");
	}
	
	public static void DisplayInvalid()
	{
		System.out.println("Invalid choice. Please choose again");
	}
	
	public static void DisplayConditionDirection()
	{
		System.out.println("condition;operator;parameter");
		System.out.println("Conditions : [NIM,name,idteam,teamname]");
		System.out.println("Operators : [=,!=]");
		System.out.println("Parameters : [data1,data2, etc...]");
	}
	


}
