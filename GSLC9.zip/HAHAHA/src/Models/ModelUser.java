package Models;

import java.util.ArrayList;

public class ModelUser {
	private String NIM;
	private String name;
	private String idTeam;
	
	public static ArrayList<String> userlist = new ArrayList<String>();
	
	public String getNIM() {
		return NIM;
	}

	public void setNIM(String NIM) {
		this.NIM = NIM;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdTeam() {
		return idTeam;
	}

	public void setIdTeam(String idTeam) {
		this.idTeam = idTeam;
	}
	
	public static void newUser(String line) {
 		userlist.add(line);
	}
	
	public static void initUserlist() 
	{
		User u = new User();
		for(int i = 0 ; i < userlist.size() ; i++) 
		{
			u.initializeUser(u.newUser(i));
		}
	}
	
	public static void updateUserlist()
	{
		User u = new User();
		for(int i = userlist.size() ; i < userlist.size() + 1 ; i++) 
		{
			u.initializeUser(u.newUser(i-1));
		}
	}
	
	
	
}
