package Models;

import java.util.ArrayList;

import Repository.SystemRepository;

public class Join extends ModelJoin {
	public static ArrayList<Join> JoinL = new ArrayList<Join>();
	
	public static void initJoin(ArrayList<User> UserL, ArrayList<Team> TeamL)
	{
		for(int i = 0; i < UserL.size() ; i++)
		{
			Join j = new Join();
			
			j.setNIM(UserL.get(i).getNIM());
			j.setName(UserL.get(i).getName());
			j.setTeamID(UserL.get(i).getIdTeam());
			j.setTeamName(SystemRepository.FIND_TEAMNAME_FROM_ID(UserL.get(i).getIdTeam()));
			
			JoinL.add(j);
		}
	}
	
	public static void updateJoin(ArrayList<User> UserL, ArrayList<Team> TeamL)
	{
		for(int i = UserL.size()-1; i < UserL.size() ; i++)
		{
			Join j = new Join();
			
			j.setNIM(UserL.get(i).getNIM());
			j.setName(UserL.get(i).getName());
			j.setTeamID(UserL.get(i).getIdTeam());
			j.setTeamName(SystemRepository.FIND_TEAMNAME_FROM_ID(UserL.get(i).getIdTeam()));
			
			JoinL.add(j);
		}
	}

}