package Models;

import java.util.ArrayList;

public class User extends ModelUser{
	
	public static ArrayList<User> UserL = new ArrayList<User>();
	
	public User newUser(int x)
	{
		User u = new User();
		
		String[] splitString = userlist.get(x).split(",");
		
		u.setNIM(splitString[0]);
		u.setName(splitString[1]);
		u.setIdTeam(splitString[2]);
		
		return u;
	}
	
	public void initializeUser(User x)
	{
		UserL.add(x);
	}
}
