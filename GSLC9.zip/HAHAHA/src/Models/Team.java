package Models;
import java.util.ArrayList;
import java.util.Iterator;
import static Models.User.*;

public class Team extends ModelTeam{
	
	public static ArrayList<Team> TeamL = new ArrayList<Team>();
	public static int[] memberCount = new int[255];
	
	public Team newTeam(int x)
	{
		Team t = new Team();
		String[] splitString = TeamList.get(x).split(",");
		t.setIdTeam(splitString[0]);;
		t.setTeamName(splitString[1]);

		return t;
	}
	
	public void initializeTeam(Team x) {
		TeamL.add(x);
	}
}