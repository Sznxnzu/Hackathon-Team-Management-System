package Models;

import java.util.ArrayList;

public class ModelTeam {
	private String idTeam;
	private String teamName;
	
	public static ArrayList<String> TeamList = new ArrayList<String>();
	
	public String getIdTeam() {
		return idTeam;
	}
	
	public void setIdTeam(String idTeam) {
		this.idTeam = idTeam;
	}
	
	public String getTeamName() {
		return teamName;
	} 
	
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	
	public static void newTeam(String str) {
		TeamList.add(str);
	}
	
	public static void initTeamlist() 
	{
		Team t = new Team();
		for(int i = 0 ; i < TeamList.size() ; i++) 
		{
			t.initializeTeam(t.newTeam(i));
		}
	}
	
	public static void updateTeamlist()
	{
		Team t = new Team();
		t.initializeTeam(t.newTeam(TeamList.size()-1));
	}
	
	
}