package Main;

import java.util.Scanner;
import static Models.Team.TeamL;
import static Models.User.UserL;
import java.io.*;
import Repository.SystemRepository;
import Display.Display;
import Models.Join;
import Select.*;


public class Main {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) throws IOException 
	{
		String tag = "initialize";
		
		while (true) 
		{
			SystemRepository.INITIALIZE_SYSTEM_STATE(tag);
			Display.DisplayMainMenu();
			
			int choice = sc.nextInt();
			sc.nextLine();
			
			switch (choice) 
			{
			case 1:
				tag = "none";
				Join.initJoin(UserL, TeamL);
				Select.SELECT_ALL_FROM_JOIN();
				
				break;
			case 2:
				Insert.InsertMenu();
				tag = "update";
				break;
			case 3:
				tag = "none";
				Show.ShowMenu();
				break;
			case 4:
				tag = "none";
				ShowOne.ShowMenu();
				break;
			case 5:
				tag = "none";
				Display.DisplayExit();
				System.exit(0);
				break;
			default:
				Display.DisplayInvalid();
				break;
			}
		}
	}
}



