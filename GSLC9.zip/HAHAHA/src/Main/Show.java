package Main;

import java.util.Scanner;

import Connection.Connection;
import Repository.TeamRepository;
import Repository.UserRepository;
import Display.Display;
import Select.Select;

public class Show {
	public static void ShowMenu()
	{
		Scanner sc = new Scanner(System.in);
		int option0 = 0;
		int option1 = 0;
		String condition;
		String c0;
		String c1;
		String c2;
		String joinOn = null;
		String[] param = new String[3];
		Connection conn = new Connection();
		
		System.out.println("Which table to show? 1. User, 2. Team");
		option0 = sc.nextInt();sc.nextLine();
		
		switch(option0)
		{
		case 1:
			System.out.println("Want to filter by condition? 1. Yes, 2. No");
			option1 = sc.nextInt();sc.nextLine();
			switch(option1)
			{
			case 1:
				UserRepository userRepository = new UserRepository();
				System.out.println("Add condition, separate by semicolon.");
				condition = sc.nextLine();
				condition.toLowerCase();				
				String[] separate = condition.split(";");
				c0 = separate[0];
				c1 = separate[1];
				c2 = separate[2];
				
				param[0] = c1;
				param[1] = c2;
				
				if(option1 == 1) {
					joinOn = "user";
				} else if(option1 == 2) {
					joinOn = "team";
				}
				
				userRepository.find(c0, param, true, joinOn, conn);
				
				break;
			case 2:
				Select.SELECT_ALL_FROM_USER();
				break;
			}
			break;
		case 2:
			System.out.println("Want to filter by condition? 1. Yes, 2. No");
//			Display.DisplayConditionDirection();
			
			option1 = sc.nextInt();sc.nextLine();
			switch(option1)
			{
			case 1:
				TeamRepository teamRepository = new TeamRepository();
				System.out.println("Add condition, separate by semicolon.");
				condition = sc.nextLine();
				condition.toLowerCase();				
				String[] separate = condition.split(";");
				c0 = separate[0];
				c1 = separate[1];
				c2 = separate[2];
				
				param[0] = c1;
				param[1] = c2;
				
				if(option1 == 1) {
					joinOn = "user";
				} else if(option1 == 2) {
					joinOn = "team";
				}
				
				teamRepository.find(c0, param, true, joinOn, conn);
				
				break;
			case 2:
				Select.SELECT_ALL_FROM_TEAM();
				break;
			}
			break;
		}
		
	}

}
