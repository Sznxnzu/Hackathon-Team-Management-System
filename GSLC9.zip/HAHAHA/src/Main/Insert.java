package Main;

import java.io.IOException;

import java.util.Scanner;

import Connection.Connection;
import Repository.TeamRepository;
import Repository.UserRepository;

public class Insert 
{
	public static String[] data = new String[4];
	public static String[] data1 = new String[2];
	
	public static void InsertMenu() throws IOException
	{
		Scanner sc = new Scanner(System.in);
		int op = 0;
		
		System.out.println("Which table to insert? [1. User, 2. Team]:");
		op = sc.nextInt();sc.nextLine();
		
		switch(op)
		{
		case 1:
			UserRepository userRepository = new UserRepository();
			Connection conn = new Connection();
			
			System.out.println("Add name: ");
			data[1] = sc.nextLine();
			
			System.out.println("Add NIM: ");
			data[0] = sc.nextLine();
			
			System.out.println("Add team: ");
			data[2] = sc.nextLine();
		
			userRepository.insert(data, conn);
			
			break;
		case 2:
			TeamRepository teamRepository = new TeamRepository();
			conn = new Connection();
			
			System.out.println("Add new team: ");
			data1[0] = sc.nextLine();
			
			teamRepository.insert(data1, conn);
			
			break;
		}
	}
}