package Select;

import static Models.Team.TeamL;
import static Models.User.UserL;
import static Models.Join.JoinL;
import static Models.Team.memberCount;

public class Select 
{
	public static void SELECT_ALL_FROM_MEMBERCOUNT()
	{
		for(int i = 0; i < TeamL.size();i++)
		{
			System.out.println("memberCount[" + i + "] : " + memberCount[i]);
		}
	}
	
	public static void SELECT_ALL_FROM_TEAM()
	{
		for(int i = 0; i<TeamL.size();i++) {
			System.out.print(TeamL.get(i).getIdTeam());
			System.out.print(TeamL.get(i).getTeamName());
			System.out.println();
		}
	}
	
	public static void SELECT_ALL_FROM_USER()
	{
		for(int i = 0; i<UserL.size(); i++)
		{
			System.out.print(UserL.get(i).getNIM());
			System.out.print(UserL.get(i).getName());
			System.out.print(UserL.get(i).getIdTeam());
			System.out.println();
		}
	}
	
	public static void SELECT_ALL_FROM_JOIN()
	{
		for(int i = 0; i<JoinL.size(); i++)
		{
			System.out.print(JoinL.get(i).getNIM());
			System.out.print(JoinL.get(i).getName());
			System.out.print(JoinL.get(i).getTeamID());
			System.out.print(JoinL.get(i).getTeamName());
			System.out.println();
		}
	}
	
	public static void SELECT_ALL_FROM_INDEX_USER(int i)
	{
		System.out.print(UserL.get(i).getNIM());
		System.out.print(UserL.get(i).getName());
		System.out.print(UserL.get(i).getIdTeam());
		System.out.println();
	}
	
	public static void SELECT_ALL_FROM_INDEX_TEAM(int i)
	{
		System.out.print(TeamL.get(i).getIdTeam());
		System.out.print(TeamL.get(i).getTeamName());
		System.out.println();
	}
	
	public static void SELECT_ALL_FROM_INDEX_JOIN(int i)
	{
		System.out.print(JoinL.get(i).getNIM());
		System.out.print(JoinL.get(i).getName());
		System.out.print(JoinL.get(i).getTeamID());
		System.out.print(JoinL.get(i).getTeamName());
		System.out.println();
	}
	
	public static void SELECT_ALLUSER_FROM_INDEX_JOIN(int i)
	{
		System.out.print(JoinL.get(i).getNIM());
		System.out.print(JoinL.get(i).getName());
		System.out.print(JoinL.get(i).getTeamID());
		System.out.println();
	}
	
	public static void SELECT_ALLTEAM_FROM_INDEX_JOIN(int i)
	{
		System.out.print(JoinL.get(i).getTeamID());
		System.out.print(JoinL.get(i).getTeamName());
		System.out.println();
	}
	
	public static void SELECT_WHERE_FROM_USER(String from, String operator, String where, String joinOn)
	{
		boolean p0,p1,p2,p3;
		p0 = Filter.FILTER_BY_NIM(from, operator, where, joinOn);
		p1 = Filter.FILTER_BY_NAME(from, operator, where, joinOn);
		p2 = Filter.FILTER_BY_TEAMNAME(from, operator, where, joinOn);
		p3 = Filter.FILTER_BY_TEAMID(from, operator, where,joinOn);
		if(!p0 && !p1 && !p2 && !p3)
		{
			System.out.println("Data does not exist");
		}
	}
	
	public static void SELECT_WHERE_FROM_TEAM(String from, String operator, String where, String joinOn) 
	{
		boolean p0,p1,p2,p3;
		p0 = Filter.FILTER_BY_NIM(from, operator, where, joinOn);
		p1 = Filter.FILTER_BY_NAME(from, operator, where, joinOn);
		p2 = Filter.FILTER_BY_TEAMNAME(from, operator, where, joinOn);
		p3 = Filter.FILTER_BY_TEAMID(from, operator, where, joinOn);
		if(!p0 && !p1 && !p2 && !p3)
		{
			System.out.println("Data does not exist");
		}
		
	}
	
	public static void SELECTONE_WHERE_FROM_USER(String from, String operator, String where, String joinOn)
	{
		boolean p0,p1,p2,p3;
		p0 = Filter.FILTERONE_BY_NIM(from, operator, where, joinOn);
		p1 = Filter.FILTERONE_BY_NAME(from, operator, where, joinOn);
		p2 = Filter.FILTERONE_BY_TEAMNAME(from, operator, where, joinOn);
		p3 = Filter.FILTERONE_BY_TEAMID(from, operator, where,joinOn);
		if(!p0 && !p1 && !p2 && !p3)
		{
			System.out.println("Data does not exist");
		}
	}
	
	public static void SELECTONE_WHERE_FROM_TEAM(String from, String operator, String where, String joinOn) 
	{
		boolean p0,p1,p2,p3;
		p0 = Filter.FILTERONE_BY_NIM(from, operator, where, joinOn);
		p1 = Filter.FILTERONE_BY_NAME(from, operator, where, joinOn);
		p2 = Filter.FILTERONE_BY_TEAMNAME(from, operator, where, joinOn);
		p3 = Filter.FILTERONE_BY_TEAMID(from, operator, where, joinOn);
		if(!p0 && !p1 && !p2 && !p3)
		{
			System.out.println("Data does not exist");
		}
		
	}
}
