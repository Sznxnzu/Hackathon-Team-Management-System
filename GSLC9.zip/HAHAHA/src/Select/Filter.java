package Select;

import static Models.User.UserL;
import static Models.Join.JoinL;
import static Models.Team.TeamL;

public class Filter {
	public static boolean FILTER_BY_NIM(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("NIM"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(condition.equals(UserL.get(i).getNIM()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(!condition.equals(UserL.get(i).getNIM()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("NIM"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(condition.equals(JoinL.get(i).getNIM()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(!condition.equals(JoinL.get(i).getNIM()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTER_BY_NAME(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("name"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(condition.equals(UserL.get(i).getName()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(!condition.equals(UserL.get(i).getName()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("name"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(condition.equals(JoinL.get(i).getName()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(!condition.equals(JoinL.get(i).getName()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTER_BY_TEAMID(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("idteam"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(condition.equals(UserL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(!condition.equals(UserL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("idteam"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(condition.equals(TeamL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
						}
					}
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(!condition.equals(TeamL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
						}
					}
				}
				return true;
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTER_BY_TEAMNAME(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("teamname"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(condition.equals(JoinL.get(i).getTeamName()))
						{
							Select.SELECT_ALLUSER_FROM_INDEX_JOIN(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(!condition.equals(JoinL.get(i).getTeamName()))
						{
							Select.SELECT_ALLUSER_FROM_INDEX_JOIN(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("teamname"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(condition.equals(TeamL.get(i).getTeamName()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(!condition.equals(TeamL.get(i).getTeamName()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
						}
					}
					return true;
				}
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTERONE_BY_NIM(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("NIM"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(condition.equals(UserL.get(i).getNIM()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(!condition.equals(UserL.get(i).getNIM()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("NIM"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(condition.equals(JoinL.get(i).getNIM()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(!condition.equals(JoinL.get(i).getNIM()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTERONE_BY_NAME(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("name"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(condition.equals(UserL.get(i).getName()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(!condition.equals(UserL.get(i).getName()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("name"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(condition.equals(JoinL.get(i).getName()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(!condition.equals(JoinL.get(i).getName()))
						{
							Select.SELECT_ALLTEAM_FROM_INDEX_JOIN(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTERONE_BY_TEAMID(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("idteam"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(condition.equals(UserL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<UserL.size(); i++)
					{
						if(!condition.equals(UserL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_USER(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("idteam"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(condition.equals(TeamL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
							break;
						}
					}
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(!condition.equals(TeamL.get(i).getIdTeam()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
							break;
						}
					}
				}
				return true;
			}
			
			return false;
		}
		
		return false;
	}
	
	public static boolean FILTERONE_BY_TEAMNAME(String from, String operator, String where, String request)
	{
		if(request.equals("user"))
		{
			if(from.equals("teamname"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(condition.equals(JoinL.get(i).getTeamName()))
						{
							Select.SELECT_ALLUSER_FROM_INDEX_JOIN(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<JoinL.size(); i++)
					{
						if(!condition.equals(JoinL.get(i).getTeamName()))
						{
							Select.SELECT_ALLUSER_FROM_INDEX_JOIN(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		else if(request.equals("team"))
		{
			if(from.equals("teamname"))
			{
				if(operator.equals("="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(condition.equals(TeamL.get(i).getTeamName()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
							break;
						}
					}
					return true;
				}
				else if(operator.equals("!="))
				{
					String condition = where;
					for(int i = 0; i<TeamL.size(); i++)
					{
						if(!condition.equals(TeamL.get(i).getTeamName()))
						{
							Select.SELECT_ALL_FROM_INDEX_TEAM(i);
							break;
						}
					}
					return true;
				}
			}
			
			return false;
		}
		
		return false;
	}

}
