package Connection;
import java.io.IOException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import Models.ModelTeam;
import Models.ModelUser;
import Models.User;
import static Models.ModelUser.userlist;
import static Models.ModelTeam.TeamList;

public class Connection 
{
	public static Boolean checkFileCSV(String FilePath)
	{
		File f = new File(FilePath);
		if(f.exists() && !f.isDirectory())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static void readFileCSV(String FilePath, String type, String state) throws NumberFormatException, IOException  
	{
		if(!Connection.checkFileCSV(FilePath))
		{
			if(type.equals("user"))
			{
				System.out.println("ERROR:userfilenotfound");
			}
			if(type.equals("teams"))
			{
				System.out.println("ERROR:teamsfilenotfound");
			}
		}
		else
		{
			File UserCSV = new File(FilePath);
			BufferedReader br = new BufferedReader(new FileReader(UserCSV));
			String nl;
			int index = 0;
			
			while((nl = br.readLine()) != null) 
			{
				index++;
				if(state.equals("initialize"))
				{
					if(type.equals("user")) 
					{
						ModelUser.newUser(nl);
					}
					else if (type.equals("teams"))
					{
						ModelTeam.newTeam(nl);
					}
				}
				else if(state.equals("update"))
				{
					if(type.equals("user") && index > userlist.size()) 
					{
						ModelUser.newUser(nl);
					}
					else if (type.equals("teams") && index > TeamList.size())
					{
						ModelTeam.newTeam(nl);
					}
				}
				
			}
			
			br.close();
		}
	}
	
	public static void writeFileCSV(String data, String FilePath) throws IOException
	{
		FileWriter myWriter = new FileWriter(FilePath, true);
	    myWriter.write(data);
	    myWriter.write(System.getProperty("line.separator"));
	    myWriter.close();
	}
}
