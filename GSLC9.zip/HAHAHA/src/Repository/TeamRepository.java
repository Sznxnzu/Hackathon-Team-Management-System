package Repository;

import static Models.Team.TeamL;

import java.io.IOException;

import Connection.Connection;
import Models.Join;
import Models.ModelTeam;
import Models.ModelUser;
import Models.User;
import Select.Select;

public class TeamRepository implements Repository{

	public void insert(String[] data, Connection conn) throws IOException 
	{
		String teamName = data[0];
		
		if(SystemRepository.CHECK_IS_TEAM_EXISTS(teamName)) 
		{
			System.out.println("ERROR : team already exist!");
			return;
		}
		else
		{
			String teamID = SystemRepository.FIND_ID_FROM_TEAMNAME(teamName);
			if(teamID.equals("-1"))
			{
				teamID = Integer.toString(TeamL.size());
				System.out.println("teamID : " + teamID);
			}
			String joinString = teamID + "," + teamName;
			Connection.writeFileCSV(joinString, "teams.csv");
			System.out.println("Team created!");
			
			Connection.readFileCSV("teams.csv", "teams", "update");
			ModelTeam.updateTeamlist();
		}
	}

	public void find(String filterOn, String[] ifwhere, boolean join, String joinOn, Connection conn) 
	{
		String d0, d1;
		d0 = ifwhere[0];
		d1 = ifwhere[1];
		
		Select.SELECT_WHERE_FROM_TEAM(filterOn, d0, d1, joinOn);
	}

	public void findOne(String filterOn, String[] ifwhere, boolean join, String joinOn, Connection conn) 
	{
		String d0, d1;
		d0 = ifwhere[0];
		d1 = ifwhere[1];
		
		Select.SELECT_WHERE_FROM_TEAM(filterOn, d0, d1, joinOn);
	}

}
