package Repository;

import static Models.Team.TeamL;
import static Models.User.UserL;

import java.io.IOException;

import Connection.Connection;
import Models.Join;
import Models.ModelUser;
import Models.User;
import Select.Select;

public class UserRepository implements Repository{

	public void insert(String[] data, Connection conn) throws IOException 
	{
		String NIM = data[0];
		String name = data[1];
		String teamName = data[2];
		
		if(!SystemRepository.CHECK_IS_TEAM_EXISTS(teamName))
		{
			System.out.println("ERROR : Team does not exist");
			System.out.println();
			return;
		}
		else
		{
			if(SystemRepository.CHECK_IS_TEAM_FULL(teamName))
			{
				System.out.println("ERROR : Team is Full");
				System.out.println();
				return;
			}
			else
			{
				String teamID = SystemRepository.FIND_ID_FROM_TEAMNAME(teamName);
				if(teamID.equals("-1"))
				{
					teamID = Integer.toString(TeamL.size());
				}
				String joinString = NIM+ ","+name+","+teamID;
				Connection.writeFileCSV(joinString, "user.csv");
				System.out.println("User created!");
				
				SystemRepository.UPDATE_MEMBERCOUNT();
				Connection.readFileCSV("user.csv", "user", "update");
				ModelUser.updateUserlist();
				Join.updateJoin(UserL, TeamL);
			}
		}
	}

	public void find(String filterOn, String[] ifwhere, boolean join, String joinOn, Connection conn) 
	{
		String d0, d1;
		d0 = ifwhere[0];
		d1 = ifwhere[1];
		
		Select.SELECT_WHERE_FROM_USER(filterOn, d0, d1, joinOn);
		
	}

	public void findOne(String filterOn, String[] ifwhere, boolean join, String joinOn, Connection conn) 
	{
		String d0, d1;
		d0 = ifwhere[0];
		d1 = ifwhere[1];
		
		Select.SELECT_WHERE_FROM_USER(filterOn, d0, d1, joinOn);
	}

}
