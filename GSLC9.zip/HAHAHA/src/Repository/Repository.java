package Repository;

import java.io.IOException;

import Connection.Connection;
import Models.Join;
import Models.ModelUser;
import Models.User;
import static Main.Insert.data;
import static Main.Insert.data1;

public interface Repository {
	
	public void insert(String[] data, Connection conn) throws IOException;
	public void find(String filterOn, String[] ifwhere, boolean join, String joinOn, Connection conn);
	public void findOne(String filterOn, String[] ifwhere, boolean join, String joinOn, Connection conn);
}
