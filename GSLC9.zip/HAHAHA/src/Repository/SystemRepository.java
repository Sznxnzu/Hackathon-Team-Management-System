package Repository;
import static Models.Team.TeamL;
import static Models.User.UserL;
import static Models.Team.memberCount;

import java.io.IOException;
import java.util.ArrayList;

import Connection.Connection;
import Models.*;

public class SystemRepository
{
	public static int NO_OPERATION_DONE(String status)
	{
		if(status.equals("initialize"))
		{
			return 1;
		}
		else if(status.equals("update"))
		{
			return 2;
		}
		else if(status.equals("none"))
		{
			return 3;
		}
		
		return 0;
	}
	
	public static void INITIALIZE_SYSTEM() throws NumberFormatException, IOException
	{
		Connection.readFileCSV("user.csv", "user", "initialize");
		Connection.readFileCSV("teams.csv", "teams", "initialize");
		ModelUser.initUserlist();
		ModelTeam.initTeamlist();
	}
	
	public static void INITIALIZE_MEMBERCOUNT()
	{
		for(int i = 0; i < UserL.size() ; i++)
		{
			String teamID = UserL.get(i).getIdTeam();
			
			for(int j = 0; j < TeamL.size() ; j++)
			{
				if(teamID.equals(Integer.toString(j)))
				{
					memberCount[j]++;
				}
			}
		}
	}
	
	public static void UPDATE_MEMBERCOUNT()
	{
		String tempteamID = UserL.get(UserL.size()-1).getIdTeam();
		int teamID = Integer.parseInt(tempteamID);
		memberCount[teamID]++;
	}
	
	public static String FIND_ID_FROM_TEAMNAME(String data)
	{
		for(int i = 0 ; i < TeamL.size() ; i++)
		{
			if(data.equals(TeamL.get(i).getTeamName()))
			{
				return Integer.toString(i);
			}
		}
		
		return "-1";
	}
	
	public static String FIND_ID_FROM_NIM(String data)
	{
		for(int i = 0 ; i < UserL.size() ; i++)
		{
			if(data.equals(UserL.get(i).getNIM()))
			{
				return UserL.get(i).getIdTeam();
			}
		}
		
		return "-1";
	}
	
	public static String FIND_TEAMNAME_FROM_ID(String data)
	{
		for(int i = 0 ; i < TeamL.size() ; i++)
		{
			if(data.equals(TeamL.get(i).getIdTeam()))
			{
				return TeamL.get(i).getTeamName();
			}
		}
		
		return "-1";
	}
	
	public static String FIND_ID_FROM_NAME(String data)
	{
		for(int i = 0 ; i < TeamL.size() ; i++)
		{
			if(data.equals(TeamL.get(i).getTeamName()))
			{
				return UserL.get(i).getIdTeam();
			}
		}
		
		return "-1";
	}
	
	public static boolean CHECK_IS_TEAM_EXISTS(String teamName)
	{
		for(int i = 0 ; i < TeamL.size() ; i++ )
		{
			if(TeamL.get(i).getTeamName().equals(teamName))
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean CHECK_IS_TEAM_FULL(String teamName)
	{
		String STRtempID = FIND_ID_FROM_TEAMNAME(teamName);
		int INTtempID = Integer.parseInt(STRtempID);
		
		if(memberCount[INTtempID]>=3)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	public static boolean CHECK_IS_INPUT_VALID(String data, String type)
	{
		if(type.equals("name"))
		{
			if(data.length()<1)
			{
				return false;
			}
			
			return true;
		}
		else if(type.equals("NIM"))
		{
			if(data.length()<1)
			{
				return false;
			}
			
			try
			{
				Integer.parseInt(data);
			}
			catch(NumberFormatException e)
			{
				return false;
			}
			
			return true;
			
		}
		else if(type.equals("teamName"))
		{
			if(data.length()<1)
			{
				return false;
			}
			
			return true;
		}
		
		return false;
	}
	
	public static void INITIALIZE_SYSTEM_STATE(String tag) throws NumberFormatException, IOException
	{
		if(SystemRepository.NO_OPERATION_DONE(tag)==1)
		{
			SystemRepository.INITIALIZE_SYSTEM();
			SystemRepository.INITIALIZE_MEMBERCOUNT();
			Join.initJoin(UserL, TeamL);
		}
	}
	
}
